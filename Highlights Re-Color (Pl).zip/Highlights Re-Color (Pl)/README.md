# Highlights Re-Color (Pl)
NTM resourcepack that re-colorizes description highlights.
